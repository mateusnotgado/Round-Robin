let processos = [120, 80, 20, 160,20 , 60]
let quantum = 20
let cores = [
	40, 111, 20,
	55, 114, 255,
	223, 41, 53,
	253, 202, 64,
	76, 159, 112,
	227, 185, 188
]
const reducer = (accumulator, currentValue) => accumulator + currentValue;
let tempo_total = processos.reduce(reducer)
let janelas = tempo_total / quantum
let largura = 1200 / janelas
let altura = 550 / processos.length 
function setup(){
	createCanvas(1200, 550)	; 
  background(200);
  desenhar_moldura();
  rr();
}
let vector;
function desenhar_moldura(){
		for(let i = 0; i < janelas; i++){
		for(let j = 0; j < processos.length; j ++){
			fill(255)
			stroke(4)
			rect(largura * i, altura * j, largura, altura)
		}
	}
} 
function rr(){
  for(let i=0;i<janelas;){
    for(let j=0;j< processos.length;j++){
      if(processos[j]>0){
        fill(cores[j],cores[j*2],cores[j*3]);
        rect(largura * i, altura * j, largura, altura)
        processos[j]=processos[j]-20;
        i++;
        
      }
    }
  }
}
